<?php get_header();?>


        <div class="container">
            <?php get_template_part('includes/section', 'content');?>
        </div>

<?php get_footer();?>